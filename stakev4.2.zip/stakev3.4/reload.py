# create : meduk
# date : 27/11/2019

import os
import json
import time
import sys
from config import *
from datetime import datetime
from hashlib import md5
from colorama import *
from getpass import getuser
try:
    import requests
except ImportError:
    exit("# module not installed !")

now = datetime.now() 
r  = requests.Session()
init(autoreset=True)
merah = Fore.LIGHTRED_EX
kuning = Fore.LIGHTYELLOW_EX
hijau = Fore.LIGHTGREEN_EX
biru = Fore.LIGHTBLUE_EX
magenta = Fore.LIGHTMAGENTA_EX
cyan = Fore.LIGHTCYAN_EX
hitam = Fore.LIGHTBLACK_EX
putih = Fore.LIGHTWHITE_EX
reset = Fore.RESET

class anycaptcha:
    def __init__(self,anticaptcha_key):
        self.ses = requests.Session()
        self.key = anticaptcha_key
        

    def recaptchav2(self,website_url,website_key):
        data = {"clientKey":self.key,"task":{"type":"RecaptchaV2TaskProxyless","websiteURL":website_url,"websiteKey":website_key}}
        req = self.ses.post("https://api.anycaptcha.com/createTask",json=data).json()
        open("logs_module.txt","a+").write(f"{json.dumps(req)}\n")
        if req["errorId"] == 0:
            return req["taskId"]
        elif req["errorId"] != 0:
            print(req)
            return False
            exit()

    def recaptchav3(self,website_url,website_key,min_score=0.3,page_action=None,isenterprise=False):
        if page_action and isenterprise:
            data = {"clientKey":self.key,"task":{"type":"RecaptchaV3TaskProxyless","websiteURL":website_url,"websiteKey":website_key,"minScore":min_score,"pageAction": page_action,"isEnterprise": False}}
            print(data)
        elif page_action:
            data = {"clientKey":self.key,"task":{"type":"RecaptchaV3TaskProxyless","websiteURL":website_url,"websiteKey":website_key,"minScore":min_score,"pageAction": page_action}}
            print(data)
        elif isenterprise:
            data = {"clientKey":self.key,"task":{"type":"RecaptchaV3TaskProxyless","websiteURL":website_url,"websiteKey":website_key,"minScore":min_score,"isEnterprise": False}}
            print(data)
        else:
            data = {"clientKey":self.key,"task":{"type":"RecaptchaV3TaskProxyless","websiteURL":website_url,"websiteKey":website_key,"minScore":min_score}}
        req = self.ses.post("https://api.anycaptcha.com/createTask",json=data).json()
        if req["errorId"] == 0:
            return req["taskId"]
        elif req["errorId"] != 0:
            return False
            print(req)
            exit()

    def hcaptchawop(self,website_url,website_key):
        data = {"clientKey":self.key,"task":{"type":"HCaptchaTaskProxyless","websiteURL":website_url,"websiteKey":website_key}}
        req = self.ses.post("https://api.anycaptcha.com/createTask",json=data).json()
        open("logs_module.txt","a+").write(f"{json.dumps(req)}\n")
        if req["errorId"] == 0:
            return req["taskId"]
        elif req["errorId"] != 1:
            print(req)
            exit()

    def getresult(self,taskid):
        data = {"clientKey":self.key,"taskId":taskid}
        while True:
            try:
                req = self.ses.post("https://api.anycaptcha.com/getTaskResult",json=data).json()
                print("# geting captcha result ! ",flush=True,end='\r')
                open("logs_module.txt","a+").write(f"{json.dumps(req)}\n")
                if req["errorId"] == 0 and req["status"] == "ready":
                    return req["solution"]["gRecaptchaResponse"]
                if req["errorId"] != 0:
                    print(req)
                    exit()
                elif req["status"] == "processing":
                    time.sleep(3)
                    continue
                else:
                    print(req)
                    exit()
            except KeyError:
                print(req)
                exit()

class anticaptcha:
    def __init__(self,anticaptcha_key):
        self.ses = requests.Session()
        self.key = anticaptcha_key

    def recaptchav2(self,website_url,website_key):
        data = {"clientKey":self.key,"task":{"type":"RecaptchaV2TaskProxyless","websiteURL":website_url,"websiteKey":website_key}}
        req = self.ses.post("https://api.anti-captcha.com/createTask",json=data).json()
        open("logs_module.txt","a+").write(f"{json.dumps(req)}\n")
        if req["errorId"] == 0:
            return req["taskId"]
        elif req["errorId"] != 0:
            print(req)
            return False
            exit()

    def recaptchav3(self,website_url,website_key,min_score=0.3,page_action=None,isenterprise=False):
        if page_action and isenterprise:
            data = {"clientKey":self.key,"task":{"type":"RecaptchaV3TaskProxyless","websiteURL":website_url,"websiteKey":website_key,"minScore":min_score,"pageAction": page_action,"isEnterprise": False}}
            print(data)
        elif page_action:
            data = {"clientKey":self.key,"task":{"type":"RecaptchaV3TaskProxyless","websiteURL":website_url,"websiteKey":website_key,"minScore":min_score,"pageAction": page_action}}
            print(data)
        elif isenterprise:
            data = {"clientKey":self.key,"task":{"type":"RecaptchaV3TaskProxyless","websiteURL":website_url,"websiteKey":website_key,"minScore":min_score,"isEnterprise": False}}
            print(data)
        else:
            data = {"clientKey":self.key,"task":{"type":"RecaptchaV3TaskProxyless","websiteURL":website_url,"websiteKey":website_key,"minScore":min_score}}
        req = self.ses.post("https://api.anti-captcha.com/createTask",json=data).json()
        if req["errorId"] == 0:
            return req["taskId"]
        elif req["errorId"] != 0:
            return False
            print(req)
            exit()

    def hcaptchawop(self,website_url,website_key):
        data = {"clientKey":self.key,"task":{"type":"HCaptchaTaskProxyless","websiteURL":website_url,"websiteKey":website_key}}
        req = self.ses.post("https://api.anti-captcha.com/createTask",json=data).json()
        open("logs_module.txt","a+").write(f"{json.dumps(req)}\n")
        if req["errorId"] == 0:
            return req["taskId"]
        elif req["errorId"] != 1:
            print(req)
            exit()

    def getresult(self,taskid):
        data = {"clientKey":self.key,"taskId":taskid}
        while True:
            try:
                req = self.ses.post("https://api.anti-captcha.com/getTaskResult",json=data).json()
                print("# geting captcha result ! ",flush=True,end='\r')
                open("logs_module.txt","a+").write(f"{json.dumps(req)}\n")
                if req["errorId"] == 0 and req["status"] == "ready":
                    return req["solution"]["gRecaptchaResponse"]
                if req["errorId"] != 0:
                    print(req)
                    exit()
                elif req["status"] == "processing":
                    time.sleep(3)
                    continue
                else:
                    print(req)
                    exit()
            except KeyError:
                print(req)
                exit()

    def _get_balance(self):
        data = {"clientKey": self.key}
        try:
            ret = self.ses.post("https://api.anti-captcha.com/getBalance", json=data).json()
        except:
            raise
        finally:
            if ret["errorId"] != 0:
                sys.exit(json.dumps(ret, indent=4))
            else:
                return ret["balance"]

class reload:
    def __init__(self):
        self.ses = requests.Session()
        self.anti = anticaptcha(ANTI_CAPTCHA_KEY)
        self.any = anycaptcha(ANY_CAPTCHA_KEY)
        self.urlApi = "https://api.stake.games/graphql"
        self.sitekey = "7830874c-13ad-4cfe-98d7-e8b019dc1742"
        self.siteurl = f"https://stake.games/?tab=reload&modal=vip&currency={COIN.lower()}"
        self.headers = {"Host": "api.stake.games","User-Agent": "Mozilla/5.0 (X11; Linux x86_64; rv:94.0) Gecko/20100101 Firefox/94.0","Accept": "*/*","Accept-Language": "en-US,en;q=0.5","Accept-Encoding": "gzip, deflate, br","Referer": "https://stake.games/","content-type": "application/json","x-access-token": "","x-lockdown-token": "s5MNWtjTM5TvCMkAzxov","x-language": "en","Origin": "https://stake.games","Content-Length": "3355","Connection": "keep-alive","Sec-Fetch-Dest": "empty","Sec-Fetch-Mode": "cors","Sec-Fetch-Site": "same-site","TE": "trailers"}
    
    def countdown(self,t):
        while t:
            print(f"# [a    ] countdown {t} seconds ",flush=True,end='\r')
            time.sleep(0.25)
            print(f"# [ab   ] countdown {t} seconds ",flush=True,end='\r')
            time.sleep(0.25)
            print(f"# [abc  ] countdown {t} seconds ",flush=True,end='\r')
            time.sleep(0.25)
            print(f"# [abcd ] countdown {t} seconds ",flush=True,end='\r')
            time.sleep(0.25)
            print(f"# [abcde] countdown {t} seconds ",flush=True,end='\r')
            time.sleep(0.25)
            t -= 1
        print("                                        ",flush=True,end='\r')

    def get_timet(self):
        localtime = time.localtime()
        jam = str(localtime.tm_hour).zfill(2)
        menit = str(localtime.tm_min).zfill(2)
        detik = str(localtime.tm_sec).zfill(2)
        return f"{jam}:{menit}:{detik}"

    def formater(self,data):
        return "{:.8f}".format(data)
        
        
    def verification_device(self):
        user = getuser() + "stake-reload"
        kemd5 = md5(bytes(user,'utf-8')).hexdigest()
        req = requests.get("https://pastebin.com/raw/R3KpPADU").json()
        self.note = req["note"]
        if kemd5 in req["list-aktivasi"]:
            return
        else:
            print("# your activation code :",kemd5)
            exit("\n# Your Code Unlisted member of Pxd-King Project ! :")

    def _my_account(self, token):
        data = {
             "query": "query initialUserRequest {\n  user {\n    ...UserAuth\n    __typename\n  }\n}\n\nfragment UserAuth on User {\n  id\n  name\n  email\n  hasPhoneNumberVerified\n  hasEmailVerified\n  hasPassword\n  intercomHash\n  createdAt\n  hasTfaEnabled\n  mixpanelId\n  hasOauth\n  flags {\n    flag\n    __typename\n  }\n  roles {\n    name\n    __typename\n  }\n  balances {\n    ...UserBalanceFragment\n    __typename\n  }\n  activeClientSeed {\n    id\n    seed\n    __typename\n  }\n  previousServerSeed {\n    id\n    seed\n    __typename\n  }\n  activeServerSeed {\n    id\n    seedHash\n    nextSeedHash\n    nonce\n    blocked\n    __typename\n  }\n  __typename\n}\n\nfragment UserBalanceFragment on UserBalance {\n  available {\n    amount\n    currency\n    __typename\n  }\n  vault {\n    amount\n    currency\n    __typename\n  }\n  __typename\n}\n",
             "operationName": "initialUserRequest",
             "variables": {}
        }
        retries = 0
        while True:
            retries += 1
            try:
                ret = self.ses.post(self.urlApi, json=data, headers = {**self.headers, "x-access-token": token})
                ret = ret.json()
            except Exception as err:
                if retries <= 3:
                    continue
                else:
                    print("{merah}[{self.get_timet()}] Something went wrong.. Account skipped!!")
                    return
            else:
                if "errors" in ret:
                    if ret["errors"][0]["errorType"] == "disabledSession":
                        print("{merah}[{self.get_timet()}] Fail: Session disabled!")
                    else:
                        print(
                            f"{merah}[{self.get_timet()}] Fail: {ret['errors'][0]['errorType']}\n"
                            f"{merah}[{self.get_timet()}] {ret['errors'][0]['message']}"
                        )
                    print("{merah}[{self.get_timet()}] Account skipped!!")
                    return
                else:
                    username = ret['data']['user']['name']
                    email = f"{ret['data']['user']['email'].split('@')[0][:4]}**"\
                            f"@{ret['data']['user']['email'].split('@')[1].split('.')[0]}"
                    balance = {
                        currency: amount
                        for amount, currency, _ in
                        [
                          i['available'].values() for i in ret['data']['user']['balances']
                        ]
                    }
                    return [username, email, balance]

    def get_crypto_index(self,data):
        if data.lower() == 'bch':
            return 0
        if data.lower() == 'btc':
            return 1
        if data.lower() == 'doge':
            return 2
        if data.lower() == 'eos':
            return 3
        if data.lower() == 'eth':
            return 4
        if data.lower() == 'ltc':
            return 5
        if data.lower() == 'trx':
            return 6
        if data.lower() == 'xrp':
            return 7

    def reload(self,token):
        _myACC = self._my_account(token)
        if not _myACC:
            return
        else:
            myName, myEmail, myBal = _myACC
        print(f"# [{self.get_timet()}] {hijau}{myName.lower()} x {myBal[COIN]:.8f} {COIN.upper()}")
        if CAPTCHA_PROVIDER.lower() == "anti-captcha":
            captcha = self.anti.hcaptchawop(self.siteurl,self.sitekey)
            captcha = self.anti.getresult(captcha)
        elif CAPTCHA_PROVIDER.lower() == "anycaptcha":
            captcha = self.any.hcaptchawop(self.siteurl,self.sitekey)
            captcha = self.any.getresult(captcha)
        print(f"# [{self.get_timet()}] {merah}Already Bypass")
        data = {"query":"mutation ClaimFaucet($currency: CurrencyEnum!, $captcha: String!) {\n  claimReload: claimFaucet(currency: $currency, captcha: $captcha) {\n    reload: faucet {\n      user {\n        id\n        reload: faucet {\n          id\n          amount(currency: $currency)\n          active\n          claimInterval\n          lastClaim\n          expireAt\n          createdAt\n          updatedAt\n          __typename\n        }\n        __typename\n      }\n      __typename\n    }\n    __typename\n  }\n}\n","operationName":"ClaimFaucet","variables":{"currency":COIN.lower(),"captcha":captcha}}
        self.headers["Content-Length"] = str(len(data))
        self.headers["x-access-token"] = token
        self.ses.headers.update(self.headers)
        req = self.ses.post(self.urlApi,json=data)
        open("result.json","w").write(req.text)
        if "errors" in req.text:
            print(f"# [{self.get_timet()}] {merah}Already claimed reload!")
            return
        else:
            try:
                index_coin = self.get_crypto_index(COIN)
                reload_amount = req.json()["data"]["claimReload"]["reload"]["user"]["reload"]["amount"]
                print(f"# [{self.get_timet()}] {hijau}Claimed {self.formater(reload_amount)} {COIN.upper()}")               
                print(f"# [{self.get_timet()}] {hijau}Balance {myBal[COIN] + reload_amount:.8f} {COIN.upper()}")

                return
            except json.decoder.JSONDecodeError:
                print(req.text)
                exit()
    
    def main(self):
        os.system("cls" if os.name == "nt" else "clear")
        print(f"""
{putih}[{hijau}*{putih}] Author {putih}: IqbalMeduk 
{putih}[{hijau}*{putih}] SCRIPT RELOAD STAKE
""")
        ListToken = open("token.txt").read().splitlines()
        if len(ListToken) == 0:
            exit(f"{cyan}[¢] no account !\n# please input in token.txt")
        while True:
            for Token in enumerate(ListToken):
                print("- " * 25)
                print(f"# [{self.get_timet()}] {kuning}Account {Token[0] + 1}/{len(ListToken)} ${self.anti._get_balance():.5f}")
                
                self.reload(Token[1])
            self.countdown(COUNTDOWN)

if __name__ == "__main__":
    try:
        app = reload()
        app.verification_device()
        app.main()
    except KeyboardInterrupt:
        exit()
