# MENGGUNAKAN CAPTCHA : anycaptcha / anti-captcha
CAPTCHA_PROVIDER = "anti-captcha"
# ANTI CAPTCHA KEY
ANTI_CAPTCHA_KEY = "keg"
# ANY CAPTCHA KE
ANY_CAPTCHA_KEY = "keg"
# COIN
COIN = "trx"
COUNTDOWN = 5 # countdown / waktu mundur / jeda claim / satuan detik
