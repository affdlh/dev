import os

while(True):
    
    os.system("python reload.py")
